# Verity (unofficial fan game) - Android project

Wraps the HTML game in a WebView. Works offline; the only permission is vibration.
The game itself lives in app/src/main/assets/index.html.

## Build the APK
Android Studio: File > Open > this folder, wait for Gradle sync, then Build > Build APK(s).
Output: app/build/outputs/apk/debug/app-debug.apk. Copy it to your phone and tap it to install.

No PC setup: push this folder to a GitHub repo, open the Actions tab, run "Build APK",
and download the "verity-apk" artifact.
